﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademicPerformance.ClassFolder
{
    class ClassTeacher
    {
        public static int IdTeacher { get; set; }
    }
}
