﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademicPerformance.ClassFolder
{
    class ClassJournal
    {
        public static string IdJournal { get; set; }
    }
}
