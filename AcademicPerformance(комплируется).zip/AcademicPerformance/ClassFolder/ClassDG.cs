﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace AcademicPerformance.ClassFolder
{
    class ClassDG
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-N9GUSG16;Initial Catalog=AcademicPerformance;Integrated Security=True");
        SqlDataAdapter adapter;
        DataGrid dataGrid;
        DataTable dataTable;

        public ClassDG(DataGrid dataGrid)
        {
            this.dataGrid = dataGrid;
        }

        public void LoadDG(string sqCommand)
        {
            try
            {
                sqlConnection.Open();
                adapter = new SqlDataAdapter(sqCommand, sqlConnection);
                dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGrid.ItemsSource = dataTable.DefaultView;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        public string SelectId()
        {
            object[] mass = null;
            string id = "";
            try
            {
                if (dataGrid != null) 
                {
                    DataRowView dataRowView = dataGrid.SelectedItem as DataRowView;
                    
                        if(dataRowView!=null)
                        {
                            DataRow dataRow = (DataRow)dataRowView.Row;
                            mass = dataRow.ItemArray;
                        }               
                }
                id = mass[0].ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }            
            return id;
        }
    }
}
