﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademicPerformance.ClassFolder
{
    class ClassDiscipline
    {
        public static int IdDiscipline { get; set; }
    }
}
